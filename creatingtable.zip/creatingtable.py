import psycopg
connect =psycopg.connect(dbname="postgres",user="postgres",password="dodo019",host="localhost",port="5432")

cursor=connect.cursor()
cursor.execute('''create table employees(Name Text, ID int,Age int);''')
print("Table created successfully")

connect.commit()
connect.close()