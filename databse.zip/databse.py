import psycopg
connect =psycopg.connect(dbname="postgres",user="postgres",password="dodo019",host="localhost",port="5432")
print("Connected successfully")
